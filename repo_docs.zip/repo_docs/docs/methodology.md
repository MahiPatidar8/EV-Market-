# Methodology

This document explains how every number in the dashboard, the Tableau views and the report is produced.

## 1. Data handling rules

1. Train and test files are inspected **separately** (schema, types, missing values, duplicates).
2. The training split is the only split used for dashboard analysis.
3. Exact duplicate rows are removed from the analysis frame or the SQLite import only. The source CSV is never modified.
4. Missing values stay `NULL` and are skipped by the aggregation that uses that field.
5. The test split is stored in its own table and is never merged into training totals.

## 2. Metric definitions

| Metric | Definition |
|---|---|
| Annual sales (KPI) | Sum of the supplied annual-sales field across the filtered rows |
| Customer rating (KPI) | Mean of the supplied rating field, ignoring `NULL` |
| Manufacturers | Count of distinct manufacturers in the filtered rows |
| Models | Count of distinct models in the filtered rows |
| CO₂ savings (KPI) | Sum of the supplied CO₂-savings field across the filtered rows |
| Range (KPI) | Mean driving range, ignoring `NULL` |
| Battery capacity (KPI) | Mean battery capacity, ignoring `NULL` |

All seven KPI cards and nine charts recompute when a filter changes.

## 2.1 Filters

Manufacturer, battery type, market region, vehicle category, manufacturing country, and model-year range.

## 3. Data flow

1. Inspect CSV files, then profile them (`data_profile.md`).
2. Import the selected split into SQLite with a schema check and duplicate removal (`database_setup.md`).
3. Flask reads the training table, applies filters, and computes KPI and chart aggregates.
4. The browser renders charts, the eight-step insight sequence, and a map. If the map library or boundaries fail to load, a country sales table is shown instead.
5. A preparation step exports a Tableau-ready CSV.
6. Tableau Public stores a published extract. GitHub embeds or links the public views. It does **not** run the Flask app or the SQLite database.

## 4. Technology

Python and pandas, Flask, SQLite with SQLAlchemy, HTML/CSS/JavaScript, Chart.js and Plotly, Tableau Public, GitHub.

## 5. Limitations

- Sales and CO₂ figures are dataset field sums, not independently verified market totals.
- Missing values change how many records a given measure uses.
- The Tableau extract is a public copy. Refresh and republish it whenever the data changes.
- Flask and SQLite run locally and are not hosted publicly.
