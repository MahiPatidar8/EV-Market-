# Demonstration Outline

Suggested length: 5 to 7 minutes.

| Time | Section | What to show |
|---|---|---|
| 0:00–0:30 | Introduction | Project title, goal, dataset source (Kaggle) |
| 0:30–1:30 | Data and SQL | Data profile, duplicate and missing-value handling, a query from `sql/analysis_queries.sql` |
| 1:30–3:30 | Flask dashboard | Seven KPI cards, nine charts, six filters, sorting, eight-step insight sequence, map and table fallback |
| 3:30–5:00 | Tableau | Dashboard 1 and the Story on Tableau Public |
| 5:00–6:00 | Repository | GitHub repo, README, `docs/` folder |
| 6:00–6:30 | Limitations and next steps | Field sums are not verified market totals; local-only Flask and SQLite; future scope |

## Checklist

- [ ] Flask app runs locally and loads the data
- [ ] Filters change the KPI cards
- [ ] Tableau links open without signing in
- [ ] Screen recording tested for audio and resolution
