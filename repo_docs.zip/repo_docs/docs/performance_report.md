# Performance Report

## 1. What was measured

Application response time of the Flask dashboard API, using the Flask **in-process test client** (no browser, network socket, CDN, concurrent users, or production server).

Environment: Windows 11, Python 3.14.2, pandas 3.0.2.
Method: load the real training CSV, time one initial dashboard request, then time 20 warmed requests.

## 2. Recorded results

| Measurement | Result |
|---|---|
| Training data load and health response | 1,465.877 ms |
| First dashboard API response | 260.409 ms |
| 20 warmed calls, median | 253.895 ms |
| 20 warmed calls, 95th percentile | 268.841 ms |
| 20 warmed calls, maximum | 276.799 ms |

All 20 warmed calls returned HTTP 200.

> These are the figures stated in the project report. **Re-run the benchmark on your own machine and replace them if they differ.**

## 3. Correctness check

A manufacturer filter was applied through the API and compared against a separate calculation on the de-duplicated training data. The comparison passed.

## 4. Tests

The repository has fourteen dashboard test functions covering aggregations, de-duplication, combined and invalid filters, empty results, missing data, Tableau embedding, the story, and SQLite import. The suite must be run again before final submission and its exact result recorded here:

```bash
python -m pytest -v
```

| Date | Tests passed / total | Notes |
|---|---|---|
| _fill in_ | _fill in_ | |

## 5. Not measured

Browser page-load time, chart rendering time, mobile behaviour, and production concurrency.
