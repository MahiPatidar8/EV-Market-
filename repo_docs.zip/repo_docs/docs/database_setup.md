# Database Setup (SQLite)

SQLite needs no server or paid account. The database is a single local file.

## 1. Prerequisites

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate     macOS/Linux: source .venv/bin/activate
pip install pandas sqlalchemy flask
```

## 2. Place the data

Download the dataset from Kaggle and put the CSV files in a local `data/` folder. This folder is **not** committed (add `data/` and `*.db` to `.gitignore`).

## 3. Create tables and import

```python
import pandas as pd
from sqlalchemy import create_engine

engine = create_engine("sqlite:///ev_market.db")

def load(csv_path, table):
    df = pd.read_csv(csv_path)
    df.columns = (df.columns.str.strip().str.lower()
                  .str.replace(r"[^a-z0-9]+", "_", regex=True).str.strip("_"))
    df = df.drop_duplicates()          # remove exact duplicate rows only
    df.to_sql(table, engine, if_exists="replace", index=False)
    print(table, len(df), "rows")

load("data/ev_market_train.csv", "ev_train")
load("data/ev_market_test.csv",  "ev_test")
```

- The test split goes into `ev_test`. It is never combined with `ev_train`.
- Column names are normalised to `snake_case`. **The queries in `sql/analysis_queries.sql` assume names such as `manufacturer`, `battery_type`, `market_region`, `vehicle_category`, `manufacturing_country`, `model_year`, `annual_sales`, `customer_rating`, `battery_capacity`, `range`, `energy_use`, `co2_savings`. Check them against your CSV header and edit the queries if yours differ.**

## 4. Optional indexes

```sql
CREATE INDEX IF NOT EXISTS idx_train_manufacturer ON ev_train(manufacturer);
CREATE INDEX IF NOT EXISTS idx_train_region ON ev_train(market_region);
CREATE INDEX IF NOT EXISTS idx_train_category ON ev_train(vehicle_category);
CREATE INDEX IF NOT EXISTS idx_train_year ON ev_train(model_year);
```

## 5. Run the queries

```bash
sqlite3 ev_market.db < sql/analysis_queries.sql
```

## 6. Run the dashboard

```bash
python app.py
```
Then open `http://127.0.0.1:5000`.

## 7. Troubleshooting

| Problem | Fix |
|---|---|
| `no such column` | A column name differs from the query. Check `PRAGMA table_info(ev_train);` |
| Database file locked | Close other programs using `ev_market.db` |
| Row count off by one | One exact duplicate row is removed on import by design |
