# Data Profile

Project: **Electric Vehicle Market Performance and Insights**
Source: [Electric Vehicle Market Classification Dataset (Kaggle)](https://www.kaggle.com/datasets/tharishreddy22/electric-vehicle-market-classification-dataset)

## 1. Files inspected

| File | Rows | Role |
|---|---|---|
| `ev_market_train.csv` | 200,000 | Training split. Used for all dashboard analysis. |
| `ev_market_test.csv` | 100,000 | Test split. Kept separate and never combined with training totals. |

> The CSV files are **not** stored in this repository. Download them from Kaggle and place them in a local `data/` folder (see `database_setup.md`).
> If your copy of the dataset has a different file name or row count (for example a single compressed `EV Vehicle.csv.gz`), update this table to match what you actually loaded.

## 2. Data quality summary (training split)

| Check | Result |
|---|---|
| Source rows | 200,000 |
| Exact duplicate rows | 1 |
| Rows analysed after removing the duplicate | 199,999 |
| Missing cells | 18,996 |

- The duplicate is removed **only** from the analysis frame (or the generated SQLite import). The original CSV is never edited.
- Missing values are left as `NULL`. A missing value is simply left out of any average or sum that uses that field.

## 3. Field groups

| Group | Fields used in the project |
|---|---|
| Identity | manufacturer, model |
| Segmentation | battery type, market region, vehicle category, manufacturing country, model year |
| Sales | annual sales |
| Customer | customer rating |
| Technical | battery capacity, driving range, energy use |
| Environmental | CO₂ savings |

## 4. How to reproduce this profile

```python
import pandas as pd

df = pd.read_csv("data/ev_market_train.csv")
print(df.shape)                    # rows, columns
print(df.dtypes)                   # field types
print(df.duplicated().sum())       # exact duplicate rows
print(df.isna().sum().sum())       # total missing cells
print(df.isna().sum().sort_values(ascending=False).head(10))
```

## 5. Interpretation limits

- Sales and CO₂ values are **sums of supplied dataset fields**.
- The source documentation does not say whether each row is a non-overlapping market-period observation, so these sums must be described as dataset aggregates and not as verified global market totals.
