# Tableau Public Workflow

## 1. Prepare the extract

1. Export a Tableau-ready CSV from the inspected source file or from the SQLite `ev_train` table (exact duplicate removed, missing values left empty).
2. Keep the original CSV unchanged.

## 2. Build the workbook

1. Open Tableau Public (Desktop) and connect to the prepared CSV.
2. Build the chart worksheets (sales by manufacturer, battery type, region, category; rating; range; battery capacity; manufacturing country map).
3. Place the worksheets on **Dashboard 1** with filters for manufacturer, battery type, region, category, country, and model year.
4. Create a **Story** that walks through the key insights.
5. Use short chart labels and tooltips to avoid crowded text.

## 3. Publish

1. Sign in to your Tableau Public account.
2. Use *File → Save to Tableau Public As…* and choose a clear workbook name.
3. Confirm the dashboard and story open in the browser.
4. Copy the public links into the report and the repository README.

## 4. Refresh

Tableau Public stores a **copy** of the data. When the data changes, regenerate the extract, refresh the workbook, and publish again.

## 5. Before publishing

Check the dataset terms on Kaggle. The extract becomes publicly downloadable once published.
