-- EV Market Performance and Insights: SQL analysis queries (SQLite)
-- Table: ev_train (training split, exact duplicates removed on import)
-- NOTE: column names are assumed. Check with:  PRAGMA table_info(ev_train);

-- 1. Row count and duplicate sanity check
SELECT COUNT(*) AS rows_analysed FROM ev_train;

-- 2. Missing values in key fields
SELECT
  SUM(annual_sales      IS NULL) AS missing_sales,
  SUM(customer_rating   IS NULL) AS missing_rating,
  SUM(battery_capacity  IS NULL) AS missing_battery,
  SUM("range"           IS NULL) AS missing_range,
  SUM(co2_savings       IS NULL) AS missing_co2
FROM ev_train;

-- 3. KPI summary (seven KPI cards)
SELECT
  SUM(annual_sales)             AS total_annual_sales,
  ROUND(AVG(customer_rating),2) AS avg_rating,
  COUNT(DISTINCT manufacturer)  AS manufacturers,
  SUM(co2_savings)              AS total_co2_savings,
  COUNT(DISTINCT model)         AS models,
  ROUND(AVG("range"),1)         AS avg_range,
  ROUND(AVG(battery_capacity),1) AS avg_battery_capacity
FROM ev_train;

-- 4. Sales by manufacturer (top 10)
SELECT manufacturer, SUM(annual_sales) AS sales
FROM ev_train GROUP BY manufacturer ORDER BY sales DESC LIMIT 10;

-- 5. Sales by battery type
SELECT battery_type, SUM(annual_sales) AS sales
FROM ev_train GROUP BY battery_type ORDER BY sales DESC;

-- 6. Sales by market region
SELECT market_region, SUM(annual_sales) AS sales
FROM ev_train GROUP BY market_region ORDER BY sales DESC;

-- 7. Sales and average rating by vehicle category
SELECT vehicle_category,
       SUM(annual_sales) AS sales,
       ROUND(AVG(customer_rating),2) AS avg_rating
FROM ev_train GROUP BY vehicle_category ORDER BY sales DESC;

-- 8. Range and energy use by vehicle category
SELECT vehicle_category,
       ROUND(AVG("range"),1)      AS avg_range,
       ROUND(AVG(energy_use),2)   AS avg_energy_use
FROM ev_train GROUP BY vehicle_category;

-- 9. Battery capacity vs range by battery type
SELECT battery_type,
       ROUND(AVG(battery_capacity),1) AS avg_battery_capacity,
       ROUND(AVG("range"),1)          AS avg_range
FROM ev_train GROUP BY battery_type;

-- 10. Sales by manufacturing country (map / fallback table)
SELECT manufacturing_country, SUM(annual_sales) AS sales
FROM ev_train GROUP BY manufacturing_country ORDER BY sales DESC;

-- 11. Model-year trend
SELECT model_year, SUM(annual_sales) AS sales, SUM(co2_savings) AS co2_savings
FROM ev_train GROUP BY model_year ORDER BY model_year;

-- 12. Example of a filtered view (replace the values)
SELECT manufacturer, SUM(annual_sales) AS sales
FROM ev_train
WHERE market_region = 'Europe'
  AND model_year BETWEEN 2018 AND 2023
GROUP BY manufacturer ORDER BY sales DESC;
